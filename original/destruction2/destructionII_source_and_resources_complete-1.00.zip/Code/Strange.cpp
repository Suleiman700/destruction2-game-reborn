#include "Strange.h"

