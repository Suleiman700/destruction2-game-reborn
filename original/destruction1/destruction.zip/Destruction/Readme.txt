
 Thank you for downloading Destruction!

 Email:   general@destruction.nu
 Website: http://www.destruction.nu

 Before using this program you must agree to the 
 disclaimer found in disclaimer.txt.

 This game is now released as freeware. Enjoy!


 Have fun! /Johan Torp


